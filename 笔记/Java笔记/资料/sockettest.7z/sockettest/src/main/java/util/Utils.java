package util;

import pojo.Client;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class Utils {


    /*
    * 用于创建 Client 对象
    * */
    public static Client creatClient(String ip, int port) {
        try {
            Selector selector = Selector.open();
            SocketChannel socketChannel = SocketChannel.open();
            socketChannel.connect(new InetSocketAddress(ip, port));
            socketChannel.configureBlocking(false).register(selector, SelectionKey.OP_READ);
            return new Client(selector, socketChannel);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    /*
    * 传入 Client 对象，创建一个线程监听服务
    * */
    public static void start(Client client) {
        new Thread(() -> {
            while (true) {
                try {
                    int select = client.getSelector().select();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
                Iterator<SelectionKey> keyIterator = client.getSelector().selectedKeys().iterator();
                while (keyIterator.hasNext()) {
                    SelectionKey next = keyIterator.next();
                    if (next.isReadable()) {
                        String msg = readAll(next);
                        System.out.println(msg);
                    }
                    keyIterator.remove();
                }
            }
        }).start();
    }

    /*
    * 读取通道中全部的数据
    * */
    public static String readAll(SelectionKey key) {
        SocketChannel channel = (SocketChannel) key.channel();
        ByteBuffer buffer = ByteBuffer.allocate(12);

        try {
            int read = channel.read(buffer);
            List<Byte> byteList = new ArrayList<>();
            while (read > 0) {
                buffer.flip();
                while (buffer.hasRemaining()) {
                    byteList.add(buffer.get());
                }
                buffer.clear();
                read = channel.read(buffer);
            }

            byte[] bytes = new byte[byteList.size()];
            for (int i = 0; i < byteList.size(); i++) {
                bytes[i] = byteList.get(i);
            }
            return new String(bytes);

        } catch (IOException e) {
            key.cancel();
            try {
                channel.socket().close();
                channel.close();
            } catch (IOException ex) {
                throw new RuntimeException(ex);
            }
        }

        return "Nothing";
    }

    /*
    * 将消息广播到除了 Server 通道以及源通道之外的所有通道中
    * */
    public static void broadcast(Set<SelectionKey> keys, SelectionKey origin, String msg) {
        keys.stream().parallel().forEach(key -> {
            if (key.channel() instanceof SocketChannel channel && key != origin) {
                try {
                    channel.write(ByteBuffer.wrap(msg.getBytes()));
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        });
    }
}
