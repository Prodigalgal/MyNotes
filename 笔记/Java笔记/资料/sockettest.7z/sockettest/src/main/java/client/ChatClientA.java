package client;

import pojo.Client;
import util.Utils;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.util.Scanner;

public class ChatClientA {

    public static void main(String[] args) {
        Client client = Utils.creatClient("127.0.0.1", 8000);
        Utils.start(client);

        Scanner sc = new Scanner(System.in);

        while (sc.hasNextLine()) {
            String line = sc.nextLine();
            try {
                client.getSocketChannel().write(ByteBuffer.wrap(line.getBytes()));
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }

    }
}
