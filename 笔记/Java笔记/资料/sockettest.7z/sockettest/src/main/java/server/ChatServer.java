package server;

import util.Utils;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.channels.SelectionKey;
import java.nio.channels.Selector;
import java.nio.channels.ServerSocketChannel;
import java.nio.channels.SocketChannel;
import java.util.Iterator;

public class ChatServer {

    public int port = 8000;
    public String ip = "127.0.0.1";
    public Selector selector;
    public ServerSocketChannel serverSocketChannel;


    public ChatServer() {
        try {
            selector = Selector.open();
            serverSocketChannel = ServerSocketChannel.open();
            serverSocketChannel.socket().bind(new InetSocketAddress(this.ip, this.port));
            serverSocketChannel.configureBlocking(false).register(selector, SelectionKey.OP_ACCEPT);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void start() {
        Selector se = this.selector;

        while (true) {
            try {
                int select = se.select();
                System.out.println("Ready:" + select);
            } catch (IOException e) {
                throw new RuntimeException(e);
            }

            Iterator<SelectionKey> keyIterator = se.selectedKeys().iterator();
            while (keyIterator.hasNext()) {
                SelectionKey next = keyIterator.next();
                if (next.isAcceptable()) {
                    connect();
                } else if (next.isReadable()) {
                    receiveMessage(next);
                }
                keyIterator.remove();
            }
        }
    }

    public void connect() {
        try {
            SocketChannel accept = this.serverSocketChannel.accept();
            accept.configureBlocking(false);
            accept.register(this.selector, SelectionKey.OP_READ);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public void receiveMessage(SelectionKey key) {
        SocketChannel channel = (SocketChannel) key.channel();
        try {
            String msg = channel.getRemoteAddress() + " say: " + Utils.readAll(key);
            System.out.println(msg);
            Utils.broadcast(this.selector.keys(), key, msg);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static void main(String[] args) {
        ChatServer chatServer = new ChatServer();
        chatServer.start();
    }
}
