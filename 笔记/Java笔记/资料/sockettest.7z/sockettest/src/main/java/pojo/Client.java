package pojo;

import java.nio.channels.Selector;
import java.nio.channels.SocketChannel;

public class Client {
    public int port = 8000;
    public String ip = "127.0.0.1";
    public Selector selector;
    public SocketChannel socketChannel;

    public Client(Selector selector, SocketChannel socketChannel) {
        this.selector = selector;
        this.socketChannel = socketChannel;
    }

    public Client(int port, String ip, Selector selector, SocketChannel socketChannel) {
        this.port = port;
        this.ip = ip;
        this.selector = selector;
        this.socketChannel = socketChannel;
    }

    public int getPort() {
        return port;
    }

    public void setPort(int port) {
        this.port = port;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public Selector getSelector() {
        return selector;
    }

    public void setSelector(Selector selector) {
        this.selector = selector;
    }

    public SocketChannel getSocketChannel() {
        return socketChannel;
    }

    public void setSocketChannel(SocketChannel socketChannel) {
        this.socketChannel = socketChannel;
    }
}
