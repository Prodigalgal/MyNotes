import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.StandardCharsets;

public class BufferTest {
    public static void main(String[] args) {
        ByteBuffer buffer = ByteBuffer.allocate(1024);
        buffer.put("A".getBytes());
        System.out.println(buffer.position());
        System.out.println(buffer.limit());

        buffer.flip();
        System.out.println(buffer.position());
        System.out.println(buffer.limit());

        CharBuffer decode = StandardCharsets.UTF_8.decode(buffer);
        System.out.println(decode);
        System.out.println(buffer.position());
        System.out.println(buffer.limit());

        buffer.clear();
        System.out.println(buffer.position());
        System.out.println(buffer.limit());
    }
}
