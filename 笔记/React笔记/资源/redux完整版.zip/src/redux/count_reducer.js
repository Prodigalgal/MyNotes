/* 
	1.该文件是用于创建一个为Count组件服务的reducer，reducer的本质就是一个函数
	2.reducer函数会接到两个参数，分别为：之前的状态(preState)，动作对象(action)
*/
import {DECREMENT, INCREMENT, SELECTNUMBER} from './constant'
// 初始化状态
const initState = {count: 0, selectNumber: 1}
export default function countReducer(preState = initState, action) {
    // 从 action 对象中获取：type、data
    const {type, data} = action
    // 根据 type 决定如何加工数据
    switch (type) {
        case INCREMENT:
            return Object.assign({}, preState, {count: preState.count + data})
        case DECREMENT:
            return  Object.assign({}, preState, {count: preState.count - data})
        case SELECTNUMBER:
            return Object.assign({}, preState, {selectNumber: data})
        default:
            return preState
    }
}