/*
    组件类
 */
import React from 'react'
// 引入store，用于获取redux中保存状态
import store from '../../redux/store'
// 引入actionCreator，专门用于创建action对象
import {createIncrementAction, createDecrementAction, createSelectNumberAction} from '../../redux/count_action'

export default function Count() {
    const increment = () => {
        const value = store.getState().selectNumber
        store.dispatch(createIncrementAction(value * 1))
    }
    const decrement = () => {
        const value = store.getState().selectNumber
        store.dispatch(createDecrementAction(value * 1))
    }
    const incrementIfOdd = () => {
        const value = store.getState().selectNumber
        const count = store.getState().count
        if (count % 2 !== 0) {
            store.dispatch(createIncrementAction(value * 1))
        }
    }
    const incrementAsync = () => {
        const value = store.getState().selectNumber
        setTimeout(() => {
            store.dispatch(createIncrementAction(value * 1))
        }, 500)
    }
    const handleSelect = (event) => {
        store.dispatch(createSelectNumberAction(event.target.value))
    }


    return (
        <div>
            <h1>当前求和为：{store.getState().count}</h1>
            <select onChange={handleSelect}>
                <option value="1">1</option>
                <option value="2">2</option>
                <option value="3">3</option>
            </select>&nbsp;
            <button onClick={increment}>+</button>
            &nbsp;
            <button onClick={decrement}>-</button>
            &nbsp;
            <button onClick={incrementIfOdd}>当前求和为奇数再加</button>
            &nbsp;
            <button onClick={incrementAsync}>异步加</button>
            &nbsp;
        </div>
    )
}
