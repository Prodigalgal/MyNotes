package main

import (
	"github.com/gin-gonic/gin"
)

//var (
//	db  *sql.DB
//	err error
//)

func main() {
	//fmt.Print("Hello\n")
	//var str = "asdasd"
	//str = str + "QQQQ"
	//fmt.Println(str + "\n")
	//var i int32 = 100
	//var n1 = int64(i)
	//
	//fmt.Printf("%v\n", i)
	//fmt.Printf("%v\n", n1)
	//
	//var i1 = 101
	//var ptr = &i1
	//
	//fmt.Print(&i1, "\n")
	//fmt.Print(ptr, "\n")
	//fmt.Print(*ptr, "\n")
	//
	//var str3 = "HHHHHH,西安u地方和司法机关房间号多少"
	//var str4 = []rune(str3)
	//
	//for index, value := range str4 {
	//	fmt.Printf("index = %d, value = %c \n", index, value)
	//}
	//
	//var result = utils.SumMy(int(i), i1)
	//fmt.Print(result)

	//i := 10
	//
	//fmt.Println("i的值：", i, " i的地址：", &i)
	//
	//p := &i
	//
	//fmt.Print("p的指向：", p, "p的值：", *p)
	//
	//*p = 20
	//
	//fmt.Print("修改后的值：", i)

	//fmt.Println("main start")
	//
	//// 管道只有10空间，主线程存入100，过度生成报错
	////chanel_1 := make(chan int, 10)
	//// 正确写法
	//chanel_1 := make(chan int, 100)
	//
	//for i := 0; i < 100; i++ {
	//	chanel_1 <- i
	//}
	//
	//go func() {
	//	fmt.Println("go1 start")
	//
	//	// 只有100个数据，读取500次，过度消费产生报错
	//	//for i := 0; i < 500; i++ {
	//	//	fmt.Println("go1 get ", <-chanel_1)
	//	//}
	//
	//	for i := 0; i < 5; i++ {
	//		fmt.Println("go1 get ", <-chanel_1)
	//	}
	//	fmt.Println("go1 end")
	//}()
	//
	//go func() {
	//	fmt.Println("go2 start")
	//	for i := 0; i < 5; i++ {
	//		fmt.Println("go2 get ", <-chanel_1)
	//	}
	//	fmt.Println("go2 end")
	//}()
	//
	//time.Sleep(10)
	//
	//fmt.Println("main end")

	//chanel := make(chan int, 10)
	//
	//go func() {
	//	for i := 0; i < 10; i++ {
	//		chanel <- i
	//	}
	//	close(chanel)
	//}()
	//
	//for {
	//	value, exist := <-chanel
	//	if exist {
	//		fmt.Println(value)
	//	} else {
	//		break
	//	}
	//}

	//http.HandleFunc("/hello/", first1)
	//http.HandleFunc("/hello/2", first2)
	//http.HandleFunc("/formTest", formTest)
	//http.ListenAndServe(":8080", nil)

	router := gin.Default()

	router.GET("/test1", func(context *gin.Context) {
		context.JSON(200, gin.H{
			"message": "test1",
		})
	})
	router.Run()
}

//func first1(w http.ResponseWriter, r *http.Request) {
//	fmt.Println("hallo1")
//	fmt.Fprintln(w, "Hello World1", r.URL.Path)
//}
//
//func first2(w http.ResponseWriter, r *http.Request) {
//	fmt.Println("hallo2")
//	fmt.Fprintln(w, "Hello World2", r.URL.Path)
//}
//
//func initDB() {
//	db, err = sql.Open("mysql", "root:admin@tcp(localhost:3306)/test")
//	if err != nil {
//		panic(err.Error())
//	}
//}
//
//func formTest(w http.ResponseWriter, r *http.Request) {
//	r.ParseForm()
//
//	cookieFromTest := http.Cookie{
//		Name:     "jsession",
//		Value:    "asdgfdgfdgdf",
//		HttpOnly: true,
//	}
//
//	http.SetCookie(w, &cookieFromTest)
//
//	jsons, _ := json.Marshal(r.Form)
//	w.Write(jsons)
//
//	fmt.Println(r.Form)
//
//}
