package com.iparking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SysModuleApplicationTests {

    @Test
    void contextLoads() {
        new Thread(() -> {

        }, "A");
        new Thread(() -> {

        }, "B");
        new Thread(() -> {

        }, "C");
    }

}
