package com.example;

import com.google.gson.Gson;
import com.iparking.commonmodule.vo.R;

import java.util.UUID;

public class UUIDTest {
    public static void main(String[] args) {
        for (int i = 0; i < 10; i++) {
            System.out.println(UUID.randomUUID());
        }

        // R r = R.error().setMessage("用户未登录");
        // Gson gson = new Gson();
        // String s = gson.toJson(r);
        // System.out.println(s);
    }
}
