package com.example;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class TimeTest {
    public static void main(String[] args) {
        try {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            LocalDateTime parse = LocalDateTime.parse("2022-06-22 19:12:58", formatter);

            System.out.println(parse);
        } catch (DateTimeParseException exception) {
            System.out.println("FUCK");
        }

    }
}
