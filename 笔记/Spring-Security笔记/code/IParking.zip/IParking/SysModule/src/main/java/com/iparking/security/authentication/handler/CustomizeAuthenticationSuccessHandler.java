package com.iparking.security.authentication.handler;

import com.iparking.commonmodule.json.JSONUtil;
import com.iparking.commonmodule.vo.R;
import com.iparking.security.authentication.details.CustomWebAuthenticationDetails;
import com.iparking.servicemodule.pojo.SecurityUser;
import com.iparking.servicemodule.service.AdminService;
import com.iparking.servicemodule.service.PropertyService;
import com.iparking.servicemodule.service.TenantService;
import com.iparking.servicemodule.service.VistorService;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

import static com.iparking.commonmodule.enums.UserType.*;


@Component
public class CustomizeAuthenticationSuccessHandler implements AuthenticationSuccessHandler {


    @Resource
    VistorService vistorService;
    @Resource
    TenantService tenantService;

    @Resource
    AdminService adminService;
    @Resource
    PropertyService propertyService;

    @Override
    public void onAuthenticationSuccess(HttpServletRequest httpServletRequest,
                                        HttpServletResponse httpServletResponse,
                                        Authentication authentication)
            throws IOException, ServletException {

        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        CustomWebAuthenticationDetails details = (CustomWebAuthenticationDetails) auth.getDetails();
        SecurityUser userDetails = (SecurityUser) auth.getPrincipal();
        String type = details.getType();
        boolean updated = update(userDetails.getUsername(), type);

        R r = R.status(updated).encryptionData("status", updated);
        httpServletResponse.setContentType("text/json;charset=utf-8");
        httpServletResponse.getWriter().write(r.toJson());
    }

    public boolean update(String username, String type) {
        boolean result = false;
        if (VISITOR.getType().equals(type)) {
            result = vistorService.updateLoginTimeByName(username);
        } else if (TENANT.getType().equals(type)) {
            result = tenantService.updateLoginTimeByName(username);
        } else if (PROPERTY.getType().equals(type)) {
            result = propertyService.updateLoginTimeByName(username);
        }
        return result;
    }
}
