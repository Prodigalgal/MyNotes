package com.iparking.controller.admin;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.iparking.commonmodule.vo.R;
import com.iparking.servicemodule.pojo.*;
import com.iparking.servicemodule.service.*;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

@RestController
@Slf4j
@RequestMapping("/api/admin")
@Tag(name = "管理员接口")
public class ListController {
    @Resource
    MenuService menuService;
    @Resource
    AreaService areaService;
    @Resource
    BillService billService;
    @Resource
    PlaceService placeService;
    @Resource
    PropertyService propertyService;
    @Resource
    RefundService refundService;
    @Resource
    RoleService roleService;
    @Resource
    TenantService tenantService;
    @Resource
    VistorService vistorService;
    @Resource
    WalletService walletService;

    @GetMapping("/menus/{page}/{limit}")
    @Operation(summary = "获取所有")
    public R getMenus(@PathVariable Integer limit,
                      @PathVariable Integer page) {
        Page<Menu> ps = new Page<>(page, limit);
        Page<Menu> list = menuService.page(ps);
        return R.ok().data("menus", list);
    }

    @GetMapping("/areas/{page}/{limit}")
    public R getAreas(@PathVariable Integer limit, @PathVariable Integer page) {
        Page<Area> ps = new Page<>(page, limit);
        Page<Area> list = areaService.page(ps);
        return R.ok().data("areas", list);
    }

    @GetMapping("/bills/{page}/{limit}")
    public R getBills(@PathVariable Integer limit, @PathVariable Integer page) {
        Page<Bill> ps = new Page<>(page, limit);
        Page<Bill> list = billService.page(ps);
        return R.ok().data("bills", list);
    }

    @GetMapping("/places/{page}/{limit}")
    public R getPlaces(@PathVariable Integer limit, @PathVariable Integer page) {
        Page<Place> ps = new Page<>(page, limit);
        Page<Place> list = placeService.page(ps);
        return R.ok().data("places", list);
    }

    @GetMapping("/propertys/{page}/{limit}")
    public R getPropertys(@PathVariable Integer limit, @PathVariable Integer page) {
        Page<Property> ps = new Page<>(page, limit);
        Page<Property> list = propertyService.page(ps);
        return R.ok().data("propertys", list);
    }

    @GetMapping("/refunds/{page}/{limit}")
    public R getRefunds(@PathVariable Integer limit, @PathVariable Integer page) {
        Page<Refund> ps = new Page<>(page, limit);
        Page<Refund> list = refundService.page(ps);
        return R.ok().data("refunds", list);
    }

    @GetMapping("/roles/{page}/{limit}")
    public R getRoles(@PathVariable Integer limit, @PathVariable Integer page) {
        Page<Role> ps = new Page<>(page, limit);
        Page<Role> list = roleService.page(ps);
        return R.ok().data("roles", list);
    }

    @GetMapping("/tenants/{page}/{limit}")
    public R getTenants(@PathVariable Integer limit, @PathVariable Integer page) {
        Page<Tenant> ps = new Page<>(page, limit);
        Page<Tenant> list = tenantService.page(ps);
        return R.ok().data("tenants", list);
    }

    @GetMapping("/vistors/{page}/{limit}")
    public R getVistors(@PathVariable Integer limit, @PathVariable Integer page) {
        Page<Vistor> ps = new Page<>(page, limit);
        Page<Vistor> list = vistorService.page(ps);
        return R.ok().data("vistors", list);
    }

    @GetMapping("/wallets/{page}/{limit}")
    public R getWallets(@PathVariable Integer limit, @PathVariable Integer page) {
        Page<Wallet> ps = new Page<>(page, limit);
        Page<Wallet> list = walletService.page(ps);
        return R.ok().data("wallets", list);
    }





}
