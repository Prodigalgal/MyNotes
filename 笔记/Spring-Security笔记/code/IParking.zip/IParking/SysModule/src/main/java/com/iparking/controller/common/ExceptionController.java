package com.iparking.controller.common;

import com.iparking.commonmodule.vo.R;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
@Slf4j
@Tag(name = "全局错误处理接口")
public class ExceptionController {

    @ExceptionHandler(Exception.class)
    public R handleException(Exception e) {
        return R.error()
                .setMessage(e.getMessage())
                .data("message", "服务器未知错误");
    }
}
