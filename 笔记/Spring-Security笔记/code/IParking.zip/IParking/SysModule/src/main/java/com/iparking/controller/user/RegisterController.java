package com.iparking.controller.user;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.iparking.commonmodule.enums.UserType;
import com.iparking.commonmodule.generate.IDGenerate;
import com.iparking.commonmodule.generate.UUIDGenerate;
import com.iparking.commonmodule.utils.ValidatorUtil;
import com.iparking.commonmodule.vo.R;
import com.iparking.servicemodule.pojo.Property;
import com.iparking.servicemodule.pojo.Tenant;
import com.iparking.servicemodule.pojo.Vistor;
import com.iparking.servicemodule.service.PropertyService;
import com.iparking.servicemodule.service.TenantService;
import com.iparking.servicemodule.service.VistorService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.parameters.P;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;
import java.util.Map;

@RestController
@Slf4j
@Tag(name = "注册接口")
@RequestMapping("/api/user")
public class RegisterController {

    @Resource
    PropertyService propertyService;
    @Resource
    TenantService tenantService;
    @Resource
    VistorService vistorService;
    @Resource
    PasswordEncoder passwordEncoder;

    @PostMapping("/register")
    @Operation(summary = "注册")
    public R register(Map<String, String> param) {
        log.info("注册接口调用");
        String username = param.get("username");
        String password = param.get("password");
        String type = param.get("type");

        if (ValidatorUtil.isUsername(username)
                && ValidatorUtil.isPassword(password)
                && ValidatorUtil.isType(type)) {
            if (type.equals(UserType.TENANT.getType())) {
                Tenant tenant = new Tenant();
                tenant.setId(IDGenerate.generate(new UUIDGenerate()));
                tenant.setUsername(username);
                tenant.setPassword(passwordEncoder.encode(password));
                tenantService.save(tenant);
            } else if (type.equals(UserType.PROPERTY.getType())) {
                Property property = new Property();
                property.setId(IDGenerate.generate(new UUIDGenerate()));
                property.setUsername(username);
                property.setPassword(passwordEncoder.encode(password));
                propertyService.save(property);
            } else if (type.equals(UserType.VISITOR.getType())) {
                Vistor vistor = new Vistor();
                vistor.setId(IDGenerate.generate(new UUIDGenerate()));
                vistor.setUsername(username);
                vistor.setPassword(passwordEncoder.encode(password));
                vistorService.save(vistor);
            }
        } else {
            return R.error().data("注册结果", "注册结果不规范");
        }
        return R.ok().data("注册结果", "注册成功");
    }

    @PostMapping("/repassword")
    @Operation(summary = "忘记密码，需要传入一个用户类型")
    public R RePassword(@RequestParam("username")String username,
                        @RequestParam("password")String password,
                        @RequestParam("type")String type) {

        boolean flag = false;
        if (type.equals(UserType.TENANT.getType())) {
            Tenant user = tenantService.getOne(new QueryWrapper<Tenant>().eq("username", username));
            user.setPassword(password);
            flag = tenantService.updateById(user);
        } else if (type.equals(UserType.PROPERTY.getType())) {
            Property user = propertyService.getOne(new QueryWrapper<Property>().eq("username", username));
            user.setPassword(password);
            flag = propertyService.updateById(user);
        } else if (type.equals(UserType.VISITOR.getType())) {
            Vistor user = vistorService.getOne(new QueryWrapper<Vistor>().eq("username", username));
            user.setPassword(password);
            flag = vistorService.updateById(user);
        }
        return R.status(flag);
    }
}
