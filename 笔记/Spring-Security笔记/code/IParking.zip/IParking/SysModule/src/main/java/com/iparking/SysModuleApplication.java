package com.iparking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SysModuleApplication {
    public static void main(String[] args) {
        SpringApplication.run(SysModuleApplication.class, args);
    }

}
