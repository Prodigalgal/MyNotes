package com.iparking.controller.common;



import com.iparking.commonmodule.vo.R;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin
@RestController
@RequestMapping("/test2")
@Tag(name = "测试接口2")
@Slf4j
public class Test2Controller {

    @GetMapping("/hallo")
    @Operation(summary = "简单的Get测试接口")
    public R getHallo() {
        log.info("测试接口2调用");
        return R.ok().setMessage("hallo");
    }

    @GetMapping("/error")
    @Operation(summary = "测试全局错误")
    public R getError() {
        log.info("测试接口error调用");
        int i = 1 / 0;
        return R.error().setMessage("error");
    }
}