package com.iparking.security.accessDecision.securityMetadataSource;

import com.iparking.servicemodule.pojo.Menu;
import com.iparking.servicemodule.pojo.Role;
import com.iparking.servicemodule.service.MenuService;
import com.iparking.servicemodule.service.RoleService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.ConfigAttribute;
import org.springframework.security.access.SecurityConfig;
import org.springframework.security.web.FilterInvocation;
import org.springframework.security.web.access.intercept.FilterInvocationSecurityMetadataSource;
import org.springframework.stereotype.Component;
import org.springframework.util.AntPathMatcher;
import org.springframework.web.util.pattern.PathPatternParser;

import javax.annotation.Resource;
import java.util.Arrays;
import java.util.List;
import java.util.Collection;
import java.util.stream.Collectors;

@Component
@Slf4j
public class CustomizeSecurityMetadataSource implements FilterInvocationSecurityMetadataSource {

    // 用于获取url以及所需的角色
    @Resource
    MenuService menuService;

    @Resource
    RoleService roleService;

    // 匹配请求的url与数据库中的url
    AntPathMatcher pathMatcher = new AntPathMatcher();

    @Override
    public Collection<ConfigAttribute> getAttributes(Object object) throws IllegalArgumentException {
        /* 根据请求地址，分析请求该地址需要什么角色 */
        log.info("查询身份");
        // 获取请求地址
        String url = ((FilterInvocation) object).getRequestUrl();
        // 获取所有地址
        List<Menu> menuList = menuService.getAllMenus();
        // 对请求地址进行匹配
        for (Menu m : menuList) {
            String pattern = m.getUrl();
            if (pathMatcher.match(pattern, url)) {
                // 获取该地址所需的角色
                List<String> nameList = roleService
                        .getRoleIdsByMenuId(m.getId())
                        .stream()
                        .map(Role::getName)
                        .collect(Collectors.toList());
                if (0 != nameList.size()) {
                    String[] names = nameList.toArray(new String[0]);
                    // 返回所需的角色
                    log.info("所需角色 {}", Arrays.toString(names));
                    return SecurityConfig.createList(names);
                }
            }
        }
        // 如果该地址无需授权，返回null
        return null;
    }

    @Override
    public Collection<ConfigAttribute> getAllConfigAttributes() {
        return null;
    }

    @Override
    public boolean supports(Class<?> clazz) {
        // 为了支持所有的类型，直接返回true
        return true;
    }
}
