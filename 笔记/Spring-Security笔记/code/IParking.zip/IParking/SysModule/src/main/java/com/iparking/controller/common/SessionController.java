package com.iparking.controller.common;

import com.iparking.commonmodule.vo.R;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Slf4j
@Tag(name = "非业务接口")
@RequestMapping("/session")
public class SessionController {

    @RequestMapping("/invalid")
    @Operation(summary = "Session失效跳转")
    public R sessionInvalid() {
        return R.error().setMessage("登陆过期");
    }
}
