package com.iparking.controller.admin;

import com.iparking.commonmodule.generate.IDGenerate;
import com.iparking.commonmodule.generate.UUIDGenerate;
import com.iparking.commonmodule.vo.R;
import com.iparking.servicemodule.pojo.Menu;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@Slf4j
@RequestMapping("/api/admin")
@Tag(name = "管理员接口")
public class AddController {

    @PostMapping("/add/menu")
    public R addMenu(Menu menu) {
        menu.setId(IDGenerate.generate(new UUIDGenerate()));
        return R.ok().data("menu", menu);
    }

}
