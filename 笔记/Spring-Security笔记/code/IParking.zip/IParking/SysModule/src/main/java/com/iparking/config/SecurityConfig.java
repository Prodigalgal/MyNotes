package com.iparking.config;

import com.iparking.security.accessDecision.securityMetadataSource.CustomizeSecurityMetadataSource;
import com.iparking.security.accessDecision.voter.CustomizeDynamicAccessDecisionVoter;
import com.iparking.security.authentication.details.CustomWebAuthenticationDetailsSource;
import com.iparking.security.authentication.entryPoint.CustomizeAuthenticationEntryPoint;
import com.iparking.security.authentication.handler.CustomizeAuthenticationFailureHandler;
import com.iparking.security.authentication.handler.CustomizeAuthenticationSuccessHandler;
import com.iparking.security.authentication.handler.CustomizeLogoutSuccessHandler;
import com.iparking.security.authentication.provider.CustomDaoAuthenticationProvider;
import com.iparking.security.session.handler.CustomizeSessionInformationExpiredStrategy;
import com.iparking.servicemodule.service.CustomUserDetailsService;
import org.jetbrains.annotations.NotNull;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.access.AccessDecisionVoter;
import org.springframework.security.access.vote.AffirmativeBased;
import org.springframework.security.config.annotation.ObjectPostProcessor;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityCustomizer;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.access.intercept.FilterSecurityInterceptor;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Resource
    private CustomDaoAuthenticationProvider customDaoAuthenticationProvider;
    @Resource
    CustomWebAuthenticationDetailsSource customWebAuthenticationDetailsSource;
    @Resource
    CustomizeAuthenticationEntryPoint customizeAuthenticationEntryPoint;
    @Resource
    CustomizeAuthenticationSuccessHandler customizeAuthenticationSuccessHandler;
    @Resource
    CustomizeAuthenticationFailureHandler customizeAuthenticationFailureHandler;
    @Resource
    CustomizeLogoutSuccessHandler customizeLogoutSuccessHandler;
    @Resource
    CustomizeSessionInformationExpiredStrategy customizeSessionInformationExpiredStrategy;
    @Resource
    CustomizeSecurityMetadataSource customizeSecurityMetadataSource;

    @Autowired
    @Qualifier("vistorUserDetailsService")
    private CustomUserDetailsService vistorUserDetailsService;

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public SecurityFilterChain filterChain(@NotNull HttpSecurity http) throws Exception {
        return http
                .formLogin()
                .loginProcessingUrl("/api/auth/login")
                .permitAll()
                .authenticationDetailsSource(customWebAuthenticationDetailsSource)
                .successHandler(customizeAuthenticationSuccessHandler)
                .failureHandler(customizeAuthenticationFailureHandler)
                .and()
                .logout()
                .logoutUrl("/api/auth/logout")
                .logoutSuccessHandler(customizeLogoutSuccessHandler)
                .deleteCookies("JSESSION")
                .and()
                .authorizeRequests()
                .anyRequest()
                .authenticated()
                .withObjectPostProcessor(new ObjectPostProcessor<FilterSecurityInterceptor>() {
                    @Override
                    public <O extends FilterSecurityInterceptor> O postProcess(O fsi) {
                        fsi.setSecurityMetadataSource(customizeSecurityMetadataSource);
                        fsi.setAccessDecisionManager(new AffirmativeBased(getDecisionVoters()));
                        return fsi;
                    }
                })
                .and()
                .csrf()
                .disable()
                .cors()
                .configurationSource(corsConfigurationSource())
                .and()
                .exceptionHandling()
                .authenticationEntryPoint(customizeAuthenticationEntryPoint)
                .and()
                .sessionManagement()
                .invalidSessionUrl("/session/invalid")
                // 最大登陆数量
                .maximumSessions(1)
                // 是否保留已经登录的用户
                .maxSessionsPreventsLogin(false)
                .expiredSessionStrategy(customizeSessionInformationExpiredStrategy)
                .and()
                .and()
                .build();
    }

    @Bean
    public AuthenticationManagerBuilder authenticationManagerBuilder(ObjectPostProcessor<Object> objectPostProcessor,
                                                                     PasswordEncoder passwordEncoder) {
        customDaoAuthenticationProvider.setUserDetailsService(vistorUserDetailsService);
        customDaoAuthenticationProvider.setPasswordEncoder(passwordEncoder);
        AuthenticationManagerBuilder managerBuilder = new AuthenticationManagerBuilder(objectPostProcessor);
        managerBuilder.authenticationProvider(customDaoAuthenticationProvider);
        return managerBuilder;
    }

    @Bean
    public WebSecurityCustomizer webSecurityCustomizer() {
        return web -> {
            web.ignoring().antMatchers("/swagger-ui.html")
                    .antMatchers( "/swagger-resources/**")
                    .antMatchers("/v3/api-docs")
                    .antMatchers("configuration/ui")
                    .antMatchers("configuration/security")
                    .antMatchers("/webjars/**");
        };
    }

    @NotNull
    private List<AccessDecisionVoter<?>> getDecisionVoters() {
        return List.of(
                new CustomizeDynamicAccessDecisionVoter()
        );
    }

    // 解决同源策源
    public CorsConfigurationSource corsConfigurationSource(){
        CorsConfiguration corsConfiguration = new CorsConfiguration();

        corsConfiguration.setAllowCredentials(true);
        corsConfiguration.setAllowedMethods(List.of("POST", "GET", "DELETE", "PUT", "OPTIONS"));

        List<String> domain = new ArrayList<>();
        for (int i = 1; i < 65525; i++) {
            String s = "http://localhost:";
            domain.add(s+i);
        }
        corsConfiguration.setAllowedOrigins(domain);
        corsConfiguration.setAllowedOriginPatterns(Collections.singletonList("*"));
        corsConfiguration.setMaxAge(3600L);

        List<String> head = List.of("Content-Type", "Cookie", "X-PINGOTHER");
        corsConfiguration.setExposedHeaders(head);
        corsConfiguration.setAllowedHeaders(head);

        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", corsConfiguration);
        return source;
    }
}
