package com.iparking.controller.user;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.iparking.commonmodule.enums.PlaceType;
import com.iparking.commonmodule.utils.AppointmentUtil;
import com.iparking.commonmodule.vo.R;
import com.iparking.servicemodule.pojo.Place;
import com.iparking.servicemodule.service.PlaceService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.parameters.P;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.time.ZoneId;
import java.time.format.DateTimeParseException;
import java.util.Date;
import java.text.DateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.concurrent.locks.ReentrantLock;
import java.util.stream.Collectors;

@RestController
@Slf4j
@RequestMapping("/api/user")
@Tag(name = "预约接口")
public class SubscribeController {

    @Resource
    PlaceService placeService;

    private final ReentrantLock lock = new ReentrantLock();


    @GetMapping("/place/{area}/{limit}/{page}")
    @Operation(summary = "获取所有空闲车位")
    public R getPlaceOnArea(@PathVariable String area, @PathVariable Integer limit, @PathVariable Integer page) {
        Page<Place> list = placeService.pageByArea(page, limit, area);
        List<Place> collect = list.getRecords().stream().filter(p -> PlaceType.Free.getStatus().equals(p.getStatus())).collect(Collectors.toList());
        list.setRecords(collect);
        return R.ok().data("places", list);
    }

    @PostMapping("/place/appointment")
    @Operation(summary = "预约车位,需要提交车位ID开始时间与结束时间")
    @Transactional(rollbackFor = Exception.class)
    public R placeAppointment(@RequestParam("id") String id, @RequestParam("startTime") String startTime, @RequestParam("endTime") String endTime) {
        Place result = placeService.getOne(new QueryWrapper<Place>().eq("id", id));
        Date st, et;
        try {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            st = Date.from(LocalDateTime.parse(startTime, formatter).atZone(ZoneId.systemDefault()).toInstant());
            et = Date.from(LocalDateTime.parse(endTime, formatter).atZone(ZoneId.systemDefault()).toInstant());
        } catch (DateTimeParseException exception) {
            return R.error().data("错误跟踪", exception.getStackTrace()).data("租借结果", "失败了，数据违规");
        }
        if (lock.tryLock()) {
            try {
                if (AppointmentUtil.isBusy(result.getStatus()) && AppointmentUtil.isTimeRight(st, et)) {
                    result.setStatus(PlaceType.BUSY.getStatus());
                    result.setStartTime(st);
                    result.setEndTime(et);
                    boolean b = placeService.updateById(result);
                    return b ? R.ok().data("租借结果", "成功了") : R.error().data("租借结果", "失败了，更新失败");
                } else {
                    if (!AppointmentUtil.isStartTimeBeforeEndTime(st, et)) {
                        return R.error().data("租借结果", "失败了，数据不和规").data("时间不合规", "起始时间需要在结束时间之前");
                    } else if (!AppointmentUtil.isStartTimeAfterNowTime(st)) {
                        return R.error().data("租借结果", "失败了，数据不和规").data("时间不合规", "起始时间需要在当前时间之后");
                    } else {
                        return R.error().data("未知错误", "未知错误");
                    }
                }
            } finally { lock.unlock(); }
        } else { return R.error().data("租借结果", "失败了，未获取锁"); }
    }

}
