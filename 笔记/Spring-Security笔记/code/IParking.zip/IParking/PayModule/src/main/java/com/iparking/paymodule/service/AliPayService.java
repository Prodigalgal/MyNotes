package com.iparking.paymodule.service;

import com.iparking.commonmodule.generate.IDGenerate;

import java.util.Map;

public interface AliPayService {
    String tradeCreate(String productId, Integer price);

    void processOrder(Map<String, String> params);

    void cancelOrder(String orderNo);

    String queryOrder(String orderNo);

    void checkOrderStatus(String orderNo);

    void refund(String orderNo, String reason);

    String queryRefund(String orderNo);

    String queryBill(String billDate, String type);

}
