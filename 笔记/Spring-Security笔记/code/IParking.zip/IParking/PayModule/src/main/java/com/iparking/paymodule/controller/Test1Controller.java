package com.iparking.paymodule.controller;

import com.iparking.commonmodule.vo.R;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin
@RestController
@RequestMapping("/test1")
@Tag(name = "测试接口1")
@Slf4j
public class Test1Controller {

    @GetMapping("/hallo")
    public R getHallo() {
        log.info("测试接口1调用");
        return R.ok().setMessage("测试接口1调用");
    }
}
