package com.iparking.commonmodule.generate;

import java.util.UUID;

public class IDGenerate {

    public static String generate(GenerateStrategy gs) {
        return gs.generate();
    }


}
