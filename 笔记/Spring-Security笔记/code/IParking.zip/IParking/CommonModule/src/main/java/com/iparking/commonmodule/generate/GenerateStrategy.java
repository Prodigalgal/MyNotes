package com.iparking.commonmodule.generate;

public interface GenerateStrategy {
    String generate();
}
