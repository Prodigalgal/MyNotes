package com.iparking.commonmodule.utils;

import com.iparking.commonmodule.enums.PlaceType;
import com.iparking.commonmodule.vo.R;

import java.util.Date;
import java.time.Instant;

public class AppointmentUtil {
    public static boolean isBusy(String status) {
        return PlaceType.Free.getStatus().equals(status);
    }

    public static boolean isTimeRight(Date startTime, Date endTime) {
        // 起始时间需要在当前时间之后
        // 结束时间需要在起始时间之后
        return isStartTimeAfterNowTime(startTime)
                && isStartTimeBeforeEndTime(startTime, endTime);
    }

    public static boolean isStartTimeBeforeEndTime(Date startTime, Date endTime) {
        return startTime.before(endTime);
    }

    public static boolean isStartTimeAfterNowTime(Date startTime) {
        Date from = Date.from(Instant.now().plusSeconds(-60));
        return startTime.after(from);
    }
}
