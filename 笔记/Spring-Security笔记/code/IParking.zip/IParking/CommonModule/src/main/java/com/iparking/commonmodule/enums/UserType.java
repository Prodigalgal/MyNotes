package com.iparking.commonmodule.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum UserType {

    VISITOR("vistor"),

    TENANT("tenant"),

    PROPERTY("property");

    private final String type;
}
