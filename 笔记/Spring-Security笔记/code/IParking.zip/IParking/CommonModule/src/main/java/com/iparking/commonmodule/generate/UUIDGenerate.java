package com.iparking.commonmodule.generate;

import java.util.UUID;

public class UUIDGenerate implements GenerateStrategy {

    @Override
    public String generate() {
        return UUID.randomUUID().toString();
    }
}
