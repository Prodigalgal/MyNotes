package com.iparking.commonmodule.enums;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public enum PlaceType {

    BUSY("占用"),

    Free("空闲"),

    Wait("结算中");

    private final String status;
}
