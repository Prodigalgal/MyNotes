package com.iparking.servicemodule.service;

import com.iparking.servicemodule.pojo.Tenant;
import com.baomidou.mybatisplus.extension.service.IService;
import com.iparking.servicemodule.pojo.Vistor;

/**
* @author zzp
* @description 针对表【tenant】的数据库操作Service
* @createDate 2022-06-14 15:27:26
*/
public interface TenantService extends IService<Tenant> {

    Tenant selectByName(String username);
    boolean updateLoginTimeByName(String username);
}
