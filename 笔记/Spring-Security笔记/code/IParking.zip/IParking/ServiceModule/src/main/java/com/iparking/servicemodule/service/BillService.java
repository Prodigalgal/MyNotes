package com.iparking.servicemodule.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.iparking.commonmodule.enums.OrderStatus;
import com.iparking.servicemodule.pojo.Bill;

import java.util.List;

/**
* @author zzp
* @description 针对表【bill】的数据库操作Service
* @createDate 2022-06-14 08:12:01
*/
public interface BillService extends IService<Bill> {
    Bill createOrderByProductId(String productId, Integer price);

    // void saveCodeUrl(String orderNo, String codeUrl);

    List<Bill> listOrderByCreateTimeDesc();

    void updateStatusByOrderNo(String id, OrderStatus orderStatus);

    String getOrderStatus(String id);

    List<Bill> getNoPayOrderByDuration(int minutes);

    Bill getOrderByOrderNo(String id);

}
