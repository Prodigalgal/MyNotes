package com.iparking.servicemodule.service;

import com.iparking.servicemodule.pojo.Property;
import com.baomidou.mybatisplus.extension.service.IService;
import com.iparking.servicemodule.pojo.Tenant;

/**
* @author zzp
* @description 针对表【property】的数据库操作Service
* @createDate 2022-06-14 15:29:20
*/
public interface PropertyService extends IService<Property> {

    Property selectByName(String username);
    boolean updateLoginTimeByName(String username);
}
