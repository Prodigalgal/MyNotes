package com.iparking.servicemodule.mapper;

import com.iparking.servicemodule.pojo.Vistor;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author zzp
* @description 针对表【vistor】的数据库操作Mapper
* @createDate 2022-06-14 15:27:18
* @Entity com.iparking.servicemodule.pojo.Vistor
*/
public interface VistorMapper extends BaseMapper<Vistor> {

}




