package com.iparking.servicemodule.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.iparking.servicemodule.pojo.Area;
import com.iparking.servicemodule.service.AreaService;
import com.iparking.servicemodule.mapper.AreaMapper;
import org.springframework.stereotype.Service;

/**
* @author zzp
* @description 针对表【area】的数据库操作Service实现
* @createDate 2022-06-15 17:32:56
*/
@Service
public class AreaServiceImpl extends ServiceImpl<AreaMapper, Area>
    implements AreaService{

}




