package com.iparking.servicemodule.service;

import com.iparking.servicemodule.pojo.Wallet;
import com.baomidou.mybatisplus.extension.service.IService;

/**
* @author zzp
* @description 针对表【wallet】的数据库操作Service
* @createDate 2022-06-20 08:56:01
*/
public interface WalletService extends IService<Wallet> {

}
