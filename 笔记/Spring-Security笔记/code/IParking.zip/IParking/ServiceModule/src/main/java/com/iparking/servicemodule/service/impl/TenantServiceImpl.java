package com.iparking.servicemodule.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.iparking.servicemodule.pojo.Tenant;
import com.iparking.servicemodule.service.TenantService;
import com.iparking.servicemodule.mapper.TenantMapper;
import org.springframework.stereotype.Service;

import java.util.Date;

/**
* @author zzp
* @description 针对表【tenant】的数据库操作Service实现
* @createDate 2022-06-14 15:27:26
*/
@Service
public class TenantServiceImpl extends ServiceImpl<TenantMapper, Tenant>
    implements TenantService{

    @Override
    public Tenant selectByName(String username) {
        return baseMapper.selectOne(new QueryWrapper<Tenant>().eq("username", username));
    }

    @Override
    public boolean updateLoginTimeByName(String username) {
        Tenant tenant = selectByName(username);
        tenant.setLastLoginTime(new Date());
        int i = baseMapper.updateById(tenant);
        return i == 1;
    }
}




