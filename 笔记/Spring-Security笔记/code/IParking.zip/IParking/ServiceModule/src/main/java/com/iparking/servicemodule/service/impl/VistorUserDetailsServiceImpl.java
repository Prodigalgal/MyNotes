package com.iparking.servicemodule.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.iparking.commonmodule.enums.UserType;
import com.iparking.servicemodule.pojo.Role;
import com.iparking.servicemodule.pojo.SecurityUser;
import com.iparking.servicemodule.pojo.Vistor;
import com.iparking.servicemodule.service.CustomUserDetailsService;
import com.iparking.servicemodule.service.RoleService;
import com.iparking.servicemodule.service.VistorService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.ArrayList;
import java.util.List;

@Service(value="vistorUserDetailsService")
@Slf4j
public class VistorUserDetailsServiceImpl implements CustomUserDetailsService {
    @Resource
    VistorService vistorService;
    @Resource
    RoleService roleService;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        log.info("开始登陆");
        Vistor vistor = vistorService.getOne(new QueryWrapper<Vistor>().eq("username", username));
        SecurityUser user;

        if(vistor == null) {
            throw new UsernameNotFoundException("用户不存在");
        } else {
            user = new SecurityUser();
            user.setUsername(vistor.getUsername());
            user.setPassword(vistor.getPassword());
        }

        List<GrantedAuthority> authorities = new ArrayList<>();
        roleService.getRolesByVistorId(vistor.getId())
                .forEach(r -> authorities.add(new SimpleGrantedAuthority(r.getName())));

        log.info("用户角色 {}", authorities);
        user.setAuthorities(authorities);
        return user;
    }

    @Override
    public boolean support(String type) {
        return type.equals(UserType.VISITOR.getType());
    }
}
