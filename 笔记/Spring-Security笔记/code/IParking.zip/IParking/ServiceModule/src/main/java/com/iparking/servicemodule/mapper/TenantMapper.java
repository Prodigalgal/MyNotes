package com.iparking.servicemodule.mapper;

import com.iparking.servicemodule.pojo.Tenant;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author zzp
* @description 针对表【tenant】的数据库操作Mapper
* @createDate 2022-06-14 15:27:26
* @Entity com.iparking.servicemodule.pojo.Tenant
*/
public interface TenantMapper extends BaseMapper<Tenant> {

}




