package com.iparking.servicemodule.vo;

public class MenuRoleVO {

}
