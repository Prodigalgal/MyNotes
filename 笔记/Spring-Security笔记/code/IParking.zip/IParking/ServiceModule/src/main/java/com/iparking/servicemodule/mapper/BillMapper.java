package com.iparking.servicemodule.mapper;


import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.iparking.servicemodule.pojo.Bill;

/**
* @author zzp
* @description 针对表【bill】的数据库操作Mapper
* @createDate 2022-06-14 08:12:01
* @Entity com.iparking.paymodule.pojo.Bill
*/
public interface BillMapper extends BaseMapper<Bill> {

}




