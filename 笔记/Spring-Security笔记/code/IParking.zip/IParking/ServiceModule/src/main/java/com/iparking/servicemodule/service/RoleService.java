package com.iparking.servicemodule.service;

import com.iparking.servicemodule.pojo.Role;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
* @author zzp
* @description 针对表【role】的数据库操作Service
* @createDate 2022-06-15 17:32:25
*/
public interface RoleService extends IService<Role> {

    List<Role> getRoleIdsByMenuId(String id);

    List<Role> getRolesByVistorId(String id);
}
