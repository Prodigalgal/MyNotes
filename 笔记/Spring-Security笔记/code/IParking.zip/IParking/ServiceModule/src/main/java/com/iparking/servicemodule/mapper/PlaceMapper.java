package com.iparking.servicemodule.mapper;

import com.iparking.servicemodule.pojo.Place;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

import java.util.Date;
import java.util.List;

/**
* @author zzp
* @description 针对表【place】的数据库操作Mapper
* @createDate 2022-06-20 09:59:40
* @Entity com.iparking.servicemodule.pojo.Place
*/
public interface PlaceMapper extends BaseMapper<Place> {
    List<Place> getPlaceShouldFree(String status, Date now);

}




