package com.iparking.servicemodule.service;

import com.iparking.servicemodule.pojo.Menu;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;


/**
* @author zzp
* @description 针对表【menu】的数据库操作Service
* @createDate 2022-06-15 17:32:13
*/
public interface MenuService extends IService<Menu> {

    List<Menu> getAllMenus();
}
