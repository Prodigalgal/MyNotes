package com.iparking.servicemodule.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.iparking.servicemodule.pojo.Wallet;
import com.iparking.servicemodule.service.WalletService;
import com.iparking.servicemodule.mapper.WalletMapper;
import org.springframework.stereotype.Service;

/**
* @author zzp
* @description 针对表【wallet】的数据库操作Service实现
* @createDate 2022-06-20 08:56:01
*/
@Service
public class WalletServiceImpl extends ServiceImpl<WalletMapper, Wallet>
    implements WalletService{

}




