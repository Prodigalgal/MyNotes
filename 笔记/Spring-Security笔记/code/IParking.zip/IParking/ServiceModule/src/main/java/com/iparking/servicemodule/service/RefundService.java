package com.iparking.servicemodule.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.iparking.servicemodule.pojo.Refund;

import java.util.List;

/**
* @author zzp
* @description 针对表【refund】的数据库操作Service
* @createDate 2022-06-14 08:36:48
*/
public interface RefundService extends IService<Refund> {

    Refund createRefundByOrderNo(String orderNo, String reason);

    void updateRefund(String content);

    List<Refund> getNoRefundOrderByDuration(int minutes);

    Refund createRefundByOrderNoForAliPay(String orderNo, String reason);

    void updateRefundForAliPay(String refundNo, String content, String refundStatus);

}
