package com.iparking.servicemodule.mapper;

import com.iparking.servicemodule.pojo.Wallet;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author zzp
* @description 针对表【wallet】的数据库操作Mapper
* @createDate 2022-06-20 08:56:01
* @Entity com.iparking.servicemodule.pojo.Wallet
*/
public interface WalletMapper extends BaseMapper<Wallet> {

}




