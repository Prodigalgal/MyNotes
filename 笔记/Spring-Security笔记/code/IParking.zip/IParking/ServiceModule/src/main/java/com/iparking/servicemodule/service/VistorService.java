package com.iparking.servicemodule.service;

import com.iparking.servicemodule.pojo.Vistor;
import com.baomidou.mybatisplus.extension.service.IService;

/**
* @author zzp
* @description 针对表【vistor】的数据库操作Service
* @createDate 2022-06-14 15:27:18
*/
public interface VistorService extends IService<Vistor> {

    Vistor selectByName(String username);

    boolean updateLoginTimeByName(String username);
}
