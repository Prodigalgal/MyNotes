package com.iparking.servicemodule.service.impl;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.iparking.servicemodule.pojo.Role;
import com.iparking.servicemodule.service.RoleService;
import com.iparking.servicemodule.mapper.RoleMapper;
import org.springframework.stereotype.Service;

import java.util.List;

/**
* @author zzp
* @description 针对表【role】的数据库操作Service实现
* @createDate 2022-06-15 17:32:25
*/
@Service
public class RoleServiceImpl extends ServiceImpl<RoleMapper, Role>
    implements RoleService{

    @Override
    public List<Role> getRoleIdsByMenuId(String id) {
        return baseMapper.getRoleIdsByMenuId(id);
    }

    @Override
    public List<Role> getRolesByVistorId(String id) {
        return baseMapper.getRolesByVistorId(id);
    }
}




