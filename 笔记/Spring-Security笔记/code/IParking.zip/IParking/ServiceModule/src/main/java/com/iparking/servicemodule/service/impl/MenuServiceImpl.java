package com.iparking.servicemodule.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.iparking.servicemodule.pojo.Menu;
import com.iparking.servicemodule.service.MenuService;
import com.iparking.servicemodule.mapper.MenuMapper;
import org.springframework.stereotype.Service;

import java.util.List;


/**
* @author zzp
* @description 针对表【menu】的数据库操作Service实现
* @createDate 2022-06-15 17:32:13
*/
@Service
public class MenuServiceImpl extends ServiceImpl<MenuMapper, Menu>
    implements MenuService{

    @Override
    public List<Menu> getAllMenus() {
        return baseMapper.selectList(new QueryWrapper<Menu>());
    }
}




