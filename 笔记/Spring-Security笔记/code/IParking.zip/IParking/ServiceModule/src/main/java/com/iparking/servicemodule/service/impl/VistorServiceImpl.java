package com.iparking.servicemodule.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.iparking.servicemodule.pojo.Vistor;
import com.iparking.servicemodule.service.VistorService;
import com.iparking.servicemodule.mapper.VistorMapper;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.Date;

/**
* @author zzp
* @description 针对表【vistor】的数据库操作Service实现
* @createDate 2022-06-14 15:27:18
*/
@Service
public class VistorServiceImpl extends ServiceImpl<VistorMapper, Vistor>
    implements VistorService{

    @Override
    public Vistor selectByName(String username) {
        return baseMapper.selectOne(new QueryWrapper<Vistor>().eq("username", username));
    }

    @Override
    public boolean updateLoginTimeByName(String username) {
        Vistor vistor = selectByName(username);
        vistor.setLastLoginTime(new Date());
        int i = baseMapper.updateById(vistor);
        return i == 1;
    }
}




