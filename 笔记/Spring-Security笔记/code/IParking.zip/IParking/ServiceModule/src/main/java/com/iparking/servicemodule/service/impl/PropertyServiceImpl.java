package com.iparking.servicemodule.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.iparking.servicemodule.pojo.Property;
import com.iparking.servicemodule.service.PropertyService;
import com.iparking.servicemodule.mapper.PropertyMapper;
import org.springframework.stereotype.Service;

import java.util.Date;

/**
* @author zzp
* @description 针对表【property】的数据库操作Service实现
* @createDate 2022-06-14 15:29:20
*/
@Service
public class PropertyServiceImpl extends ServiceImpl<PropertyMapper, Property>
    implements PropertyService{

    @Override
    public Property selectByName(String username) {
        return baseMapper.selectOne(new QueryWrapper<Property>().eq("username", username));
    }

    @Override
    public boolean updateLoginTimeByName(String username) {
        Property property = selectByName(username);
        property.setLastLoginTime(new Date());
        int i = baseMapper.updateById(property);
        return i == 1;
    }
}




