package com.iparking.servicemodule.task;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.iparking.commonmodule.enums.OrderStatus;
import com.iparking.commonmodule.enums.PlaceType;
import com.iparking.servicemodule.pojo.Bill;
import com.iparking.servicemodule.pojo.Place;
import com.iparking.servicemodule.service.BillService;
import com.iparking.servicemodule.service.PlaceService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Component
public class PlaceTask {

    @Resource
    PlaceService placeService;
    @Resource
    BillService billService;

    @Scheduled(cron = "0/30 * * * * ?")
    public void releasePlace() {
        log.info("releasePlace 被执行......");

        List<Place> places = placeService.getPlaceShouldFree();
        places.forEach(x -> {
            long num = billService.list(new QueryWrapper<Bill>().eq("place_id", x.getId()))
                    .stream()
                    .filter(b -> !OrderStatus.SUCCESS.getType().equals(b.getPayStatus())).count();
            if (0 == num && PlaceType.Wait.equals(x.getStatus())) {
                x.setStatus(PlaceType.Free.getStatus());
            }
        });
        boolean b = placeService.updateBatchById(places);

        log.info("更新数量 {}, 更新结果 {}", places.size(), b);
    }

}
