package com.iparking.servicemodule.service;

import com.iparking.servicemodule.pojo.Area;
import com.baomidou.mybatisplus.extension.service.IService;

/**
* @author zzp
* @description 针对表【area】的数据库操作Service
* @createDate 2022-06-15 17:32:56
*/
public interface AreaService extends IService<Area> {

}
