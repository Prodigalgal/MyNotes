package com.iparking.servicemodule.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.iparking.commonmodule.enums.PlaceType;
import com.iparking.servicemodule.pojo.Area;
import com.iparking.servicemodule.pojo.Place;
import com.iparking.servicemodule.service.AreaService;
import com.iparking.servicemodule.service.PlaceService;
import com.iparking.servicemodule.mapper.PlaceMapper;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

/**
 * @author zzp
 * @description 针对表【place】的数据库操作Service实现
 * @createDate 2022-06-20 09:59:40
 */
@Service
public class PlaceServiceImpl extends ServiceImpl<PlaceMapper, Place>
        implements PlaceService {

    @Resource
    AreaService areaService;

    @Override
    public Page<Place> pageByArea(Integer page, Integer limit, String area) {
        Area name = areaService.getOne(new QueryWrapper<Area>().eq("name", area));
        return baseMapper.selectPage(new Page<>(page, limit), new QueryWrapper<Place>().eq("area_id", name.getId()));
    }

    @Override
    public List<Place> getPlaceShouldFree() {
        return baseMapper.getPlaceShouldFree(PlaceType.Wait.getStatus(), new Date());
    }
}




