package com.iparking.servicemodule.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.google.gson.Gson;
import com.iparking.commonmodule.enums.RefundStatus;
import com.iparking.commonmodule.generate.IDGenerate;
import com.iparking.commonmodule.generate.UUIDGenerate;
import com.iparking.servicemodule.mapper.RefundMapper;
import com.iparking.servicemodule.pojo.Bill;
import com.iparking.servicemodule.pojo.Refund;
import com.iparking.servicemodule.service.BillService;
import com.iparking.servicemodule.service.RefundService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.time.Duration;
import java.time.Instant;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/**
 * @author zzp
 * @description 针对表【refund】的数据库操作Service实现
 * @createDate 2022-06-14 08:36:48
 */
@Service
public class RefundServiceImpl extends ServiceImpl<RefundMapper, Refund> implements RefundService {


    @Resource
    private BillService billService;

    /**
     * 根据订单号创建退款订单
     *
     * @param orderNo
     * @return
     */
    @Override
    public Refund createRefundByOrderNo(String orderNo, String reason) {

        // 根据订单号获取订单信息
        Bill bill = billService.getOrderByOrderNo(orderNo);

        // 根据订单号生成退款订单
        Refund refund = new Refund();
        refund.setBillId(orderNo); // 订单编号
        refund.setId(IDGenerate.generate(new UUIDGenerate())); // 退款单编号
        refund.setPrice(bill.getPrice()); // 退款金额(分)
        refund.setReason(reason); // 退款原因

        // 保存退款订单
        baseMapper.insert(refund);

        return refund;
    }


    /**
     * 记录退款记录
     *
     * @param content
     */
    @Override
    public void updateRefund(String content) {

        // 将json字符串转换成Map
        Gson gson = new Gson();
        Map<String, String> resultMap = gson.fromJson(content, HashMap.class);

        // 根据退款单编号修改退款单
        QueryWrapper<Refund> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("id", resultMap.get("out_refund_no"));

        // 设置要修改的字段
        Refund refund = new Refund();

        refund.setId(resultMap.get("refund_id")); // 微信支付退款单号

        // 查询退款和申请退款中的返回参数
        if (resultMap.get("status") != null) {
            refund.setStatus(resultMap.get("status"));//退款状态
            // refund.setContentReturn(content); // 将全部响应结果存入数据库的content字段
        }
        // 退款回调中的回调参数
        if (resultMap.get("refund_status") != null) {
            refund.setStatus(resultMap.get("refund_status"));//退款状态
            // refund.setContentNotify(content);//将全部响应结果存入数据库的content字段
        }

        // 更新退款单
        baseMapper.update(refund, queryWrapper);
    }

    /**
     * 找出申请退款超过minutes分钟并且未成功的退款单
     *
     * @param minutes
     * @return
     */
    @Override
    public List<Refund> getNoRefundOrderByDuration(int minutes) {

        // minutes分钟之前的时间
        Instant instant = Instant.now().minus(Duration.ofMinutes(minutes));

        QueryWrapper<Refund> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("status", RefundStatus.PROCESSING.getType());
        queryWrapper.le("create_time", instant);
        List<Refund> refundInfoList = baseMapper.selectList(queryWrapper);
        return refundInfoList;
    }

    /**
     * 根据订单号创建退款订单
     *
     * @param orderNo
     * @return
     */
    @Override
    public Refund createRefundByOrderNoForAliPay(String orderNo, String reason) {

        // 根据订单号获取订单信息
        Bill bill = billService.getOrderByOrderNo(orderNo);

        // 根据订单号生成退款订单
        Refund Refund = new Refund();
        Refund.setBillId(orderNo); // 订单编号
        Refund.setId(IDGenerate.generate(new UUIDGenerate())); // 退款单编号

        Refund.setPrice(bill.getPrice()); // 退款金额(分)
        Refund.setReason(reason); // 退款原因

        // 保存退款订单
        baseMapper.insert(Refund);

        return Refund;
    }

    /**
     * 更新退款记录
     *
     * @param refundNo
     * @param content
     * @param refundStatus
     */
    @Override
    public void updateRefundForAliPay(String refundNo, String content, String refundStatus) {

        //根据退款单编号修改退款单
        QueryWrapper<Refund> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("id", refundNo);

        //设置要修改的字段
        Refund Refund = new Refund();
        Refund.setStatus(refundStatus); // 退款状态
        // Refund.setContentReturn(content); // 将全部响应结果存入数据库的content字段

        //更新退款单
        baseMapper.update(Refund, queryWrapper);

    }
}




