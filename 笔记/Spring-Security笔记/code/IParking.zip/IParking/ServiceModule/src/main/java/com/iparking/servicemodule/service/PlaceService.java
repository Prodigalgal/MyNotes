package com.iparking.servicemodule.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.iparking.servicemodule.pojo.Place;
import com.baomidou.mybatisplus.extension.service.IService;

import java.util.List;

/**
* @author zzp
* @description 针对表【place】的数据库操作Service
* @createDate 2022-06-20 09:59:40
*/
public interface PlaceService extends IService<Place> {

    Page<Place> pageByArea(Integer page, Integer limit, String area);

    List<Place> getPlaceShouldFree();
}
