package com.iparking.servicemodule.mapper;

import com.iparking.servicemodule.pojo.Admin;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author zzp
* @description 针对表【admin】的数据库操作Mapper
* @createDate 2022-06-14 15:29:13
* @Entity com.iparking.servicemodule.pojo.Admin
*/
public interface AdminMapper extends BaseMapper<Admin> {

}




