package com.iparking.servicemodule.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.iparking.commonmodule.enums.OrderStatus;
import com.iparking.commonmodule.generate.IDGenerate;
import com.iparking.commonmodule.generate.UUIDGenerate;
import com.iparking.servicemodule.mapper.BillMapper;
import com.iparking.servicemodule.mapper.PlaceMapper;
import com.iparking.servicemodule.mapper.TenantMapper;
import com.iparking.servicemodule.pojo.Bill;
import com.iparking.servicemodule.pojo.Place;
import com.iparking.servicemodule.service.BillService;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.time.Duration;
import java.time.Instant;
import java.util.List;
import java.util.UUID;

/**
* @author zzp
* @description 针对表【bill】的数据库操作Service实现
* @createDate 2022-06-13 18:30:50
*/
@Service
public class BillServiceImpl extends ServiceImpl<BillMapper, Bill>
    implements BillService {

    @Resource
    private PlaceMapper placeMapper;

    @Resource
    private TenantMapper tenantMapper;

    @Override
    public Bill createOrderByProductId(String productId, Integer price) {

        // 查找已存在但未支付的订单
        Bill bill = this.getNoPayOrderByProductId(productId);
        if( bill != null){
            return bill;
        }

        // 获取商品信息
        Place place = placeMapper.selectById(productId);

        // 生成订单
        bill = new Bill();
        bill.setId(IDGenerate.generate(new UUIDGenerate())); // 订单号
        bill.setPlaceId(productId); // 商品ID
        bill.setPrice(price); // 价格
        bill.setSellerNo(place.getOnwerId()); // 商家ID
        bill.setPayStatus(OrderStatus.NOTPAY.getType()); // 未支付
        baseMapper.insert(bill);
        return bill;
    }

    /**
     * 存储订单二维码
     * @param orderNo
     * @param codeUrl
    @Override
    public void saveCodeUrl(String orderNo, String codeUrl) {
        QueryWrapper<Bill> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("order_no", orderNo);
        Bill Bill = new Bill();
        baseMapper.update(Bill, queryWrapper);
    }
     */

    /**
     * 查询订单列表，并倒序查询
     * @return
     */
    @Override
    public List<Bill> listOrderByCreateTimeDesc() {
        QueryWrapper<Bill> queryWrapper = new QueryWrapper<Bill>().orderByDesc("create_time");
        return baseMapper.selectList(queryWrapper);
    }

    /**
     * 根据订单号更新订单状态
     */
    @Override
    public void updateStatusByOrderNo(String id, OrderStatus status) {
        QueryWrapper<Bill> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("id", id);

        Bill Bill = new Bill();
        Bill.setPayStatus(status.getType());

        baseMapper.update(Bill, queryWrapper);
    }

    /**
     * 根据订单号获取订单状态
     * @return
     */
    @Override
    public String getOrderStatus(String id) {

        QueryWrapper<Bill> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("id", id);
        Bill Bill = baseMapper.selectOne(queryWrapper);
        if(Bill == null){
            return null;
        }
        return Bill.getPayStatus();
    }

    /**
     * 查询创建超过minutes分钟并且未支付的订单
     * @param minutes
     * @return
     */
    @Override
    public List<Bill> getNoPayOrderByDuration(int minutes) {

        Instant instant = Instant.now().minus(Duration.ofMinutes(minutes));

        QueryWrapper<Bill> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("pay_status", OrderStatus.NOTPAY.getType());
        queryWrapper.le("create_time", instant);

        List<Bill> BillList = baseMapper.selectList(queryWrapper);

        return BillList;
    }

    /**
     * 根据订单号获取订单
     * @param orderNo
     * @return
     */
    @Override
    public Bill getOrderByOrderNo(String orderNo) {

        QueryWrapper<Bill> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("id", orderNo);
        Bill Bill = baseMapper.selectOne(queryWrapper);

        return Bill;
    }


    /**
     * 根据商品id查询未支付订单
     * 防止重复创建订单对象
     * @param productId
     * @return
     */
    private Bill getNoPayOrderByProductId(String productId) {

        QueryWrapper<Bill> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("place_id", productId);
        queryWrapper.eq("pay_status", OrderStatus.NOTPAY.getType());

        Bill Bill = baseMapper.selectOne(queryWrapper);
        return Bill;
    }

}




