package com.iparking.servicemodule.mapper;

import com.iparking.servicemodule.pojo.Area;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author zzp
* @description 针对表【area】的数据库操作Mapper
* @createDate 2022-06-15 17:32:56
* @Entity com.iparking.servicemodule.pojo.Area
*/
public interface AreaMapper extends BaseMapper<Area> {

}




