package com.iparking.servicemodule.mapper;

import com.iparking.servicemodule.pojo.Property;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
* @author zzp
* @description 针对表【property】的数据库操作Mapper
* @createDate 2022-06-14 15:29:20
* @Entity com.iparking.servicemodule.pojo.Property
*/
public interface PropertyMapper extends BaseMapper<Property> {

}




